using System;
using Xunit;

namespace ABP.LiteProject.TestBase
{
    public class UnitTest1
    {
        [Fact]
        public void Test1()
        {

        }
    }
}
