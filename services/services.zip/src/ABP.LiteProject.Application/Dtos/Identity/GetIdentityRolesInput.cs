﻿using Volo.Abp.Application.Dtos;

namespace ABP.LiteProject.Application.Dtos.Identity
{
    public class GetIdentityRolesInput : PagedAndSortedResultRequestDto
    {
        public string Filter { get; set; }
    }
}