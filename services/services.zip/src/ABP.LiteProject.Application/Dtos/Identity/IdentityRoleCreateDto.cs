﻿namespace ABP.LiteProject.Application.Dtos.Identity
{

    public class IdentityRoleCreateDto : IdentityRoleCreateOrUpdateDtoBase
    {

    }
}