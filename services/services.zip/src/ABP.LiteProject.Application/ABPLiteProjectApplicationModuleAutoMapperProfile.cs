﻿using ABP.LiteProject.Application.Dtos.Identity;
using AutoMapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Volo.Abp.Identity;

namespace ABP.LiteProject.Application
{
    public class ABPLiteProjectApplicationModuleAutoMapperProfile : Profile
    {
        public ABPLiteProjectApplicationModuleAutoMapperProfile()
        {
            CreateMap<IdentityUser, IdentityUserDto>()
                .MapExtraProperties();

            CreateMap<IdentityRole, IdentityRoleDto>()
                .MapExtraProperties();
        }
    }
}
