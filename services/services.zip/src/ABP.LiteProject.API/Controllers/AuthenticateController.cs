﻿using ABP.LiteProject.API.Extensions;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Volo.Abp;
using Volo.Abp.AspNetCore.Mvc;
using Volo.Abp.Identity;
using Volo.Abp.Identity.AspNetCore;
using IdentityUser = Volo.Abp.Identity.IdentityUser;
using UserLoginInfo = ABP.LiteProject.API.Controllers.Models.UserLoginInfo;

namespace ABP.LiteProject.API.Controllers
{
    [Route("api/[controller]")]
    public class AuthController : AbpControllerBase
    {
        protected SignInManager<IdentityUser> SignInManager { get; }
        protected IdentityUserManager UserManager { get; }
        protected IdentitySecurityLogManager IdentitySecurityLogManager { get; }
        protected IConfiguration Configuration { get; }
        public AuthController(SignInManager<IdentityUser> signInManager, IdentityUserManager userManager, IdentitySecurityLogManager identitySecurityLogManager, IConfiguration configuration)
        {
            SignInManager = signInManager;
            UserManager = userManager;
            IdentitySecurityLogManager = identitySecurityLogManager;
            Configuration = configuration;
        }

        [HttpPost]
        public async Task<string> GetAsync(UserLoginInfo userLoginInfo)
        {
            if (userLoginInfo == null || userLoginInfo.UserName.IsNullOrEmpty() || userLoginInfo.Password.IsNullOrEmpty())
            {
                throw new UserFriendlyException("账号和密码不能为空");
            }
            var user = await UserManager.FindByNameAsync(userLoginInfo.UserName);

            var signInResult = await SignInManager.CheckPasswordSignInAsync(user, userLoginInfo.Password, true);
            await IdentitySecurityLogManager.SaveAsync(new IdentitySecurityLogContext()
            {
                Identity = IdentitySecurityLogIdentityConsts.Identity,
                Action = signInResult.ToIdentitySecurityLogAction(),
                UserName = userLoginInfo.UserName
            });
            if (signInResult.IsLockedOut)
            {
                throw new UserFriendlyException("账户已锁定");
            }

            if (signInResult.IsNotAllowed)
            {
                throw new UserFriendlyException("账户已锁定");
            }

            if (!signInResult.Succeeded)
            {
                throw new UserFriendlyException("登录失败");
            }
            var secretKey = Configuration["App:Identity:JwtSecretKey"];
            var token = await UserManager.GenerateAuthenticationTokenAsync(user, secretKey);
            await UserManager.SetAuthenticationTokenAsync(user, JwtBearerDefaults.AuthenticationScheme, "access_token", token);
            return token;
        }
    }
}
