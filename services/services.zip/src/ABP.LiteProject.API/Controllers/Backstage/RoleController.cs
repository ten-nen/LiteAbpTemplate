﻿using ABP.LiteProject.Application.Dtos.Identity;
using ABP.LiteProject.Application.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Volo.Abp;
using Volo.Abp.Application.Dtos;
using Volo.Abp.Identity;

namespace ABP.LiteProject.API.Controllers.Backstage
{
    public class RoleController : BackstageControllerBase
    {
        protected IIdentityRoleService IdentityRoleService { get; }

        public RoleController(IIdentityRoleService identityRoleService)
        {
            IdentityRoleService = identityRoleService;
        }

        [HttpGet]
        public async Task<PagedResultDto<IdentityRoleDto>> GetListAsync(GetIdentityRolesInput input)
        {
            return await IdentityRoleService.GetListAsync(input);
        }

        [HttpGet]
        [Route("{id}")]
        public async Task<IdentityRoleDto> GetAsync(Guid id)
        {
            return await IdentityRoleService.GetAsync(id);
        }

        [HttpPost]
        public async Task<IdentityRoleDto> CreateAsync(IdentityRoleCreateDto input)
        {
            return await IdentityRoleService.CreateAsync(input);
        }

        [HttpPut]
        [Route("{id}")]
        public async Task<IdentityRoleDto> UpdateAsync(Guid id, IdentityRoleUpdateDto input)
        {
            return await IdentityRoleService.UpdateAsync(id, input);
        }

        [HttpDelete]
        [Route("{id}")]
        public async Task DeleteAsync(Guid id)
        {
            await IdentityRoleService.DeleteAsync(id);
        }

        [HttpGet("Tnt")]
        public async Task<string> TestAsync()
        {
            throw new UserFriendlyException("登录失败");
        }
    }
}
