﻿using ABP.LiteProject.API.Controllers.Backstage;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc.Infrastructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using Volo.Abp.Authorization.Permissions;
using Volo.Abp.Data;
using Volo.Abp.MultiTenancy;
using Volo.Abp.PermissionManagement;

namespace ABP.LiteProject.API.Permissions
{
    public class RolePathPermissionDefinitionProvider : PermissionDefinitionProvider
    {
        private readonly IActionDescriptorCollectionProvider _provider;
        public RolePathPermissionDefinitionProvider(IActionDescriptorCollectionProvider provider)
        {
            _provider = provider;
        }
        public override void Define(IPermissionDefinitionContext context)
        {
            var policies = ApiPermissions.GetAll();
            var abpControllerTypes = Assembly.GetAssembly(typeof(Program))
                                  .GetTypes();
            foreach (var p in policies)
            {
                var group = context.AddGroup(p);
                group.AddPermission(p).WithProviders(RolePathPermissionValueProvider.ProviderName);


                var policyControllerTypes = abpControllerTypes.Where(v => v.GetCustomAttributes<AuthorizeAttribute>(true).Any(attr => attr.Policy == p));
                var policyControllerActions = policyControllerTypes.SelectMany(v => v.GetMethods(BindingFlags.Instance | BindingFlags.DeclaredOnly | BindingFlags.Public))
                                            .Where(v => !v.GetCustomAttributes(typeof(System.Runtime.CompilerServices.CompilerGeneratedAttribute), true).Any())
                                            .Select(v =>
                                            {
                                                var controller = v.DeclaringType.Name.Replace("Controller", "");
                                                var action = v.Name.EndsWith("Async") ? v.Name.Remove(v.Name.IndexOf("Async")) : v.Name;
                                                return new { controller, action };
                                            })
                                            .ToList();
                foreach (var controller in policyControllerActions.Select(v => v.controller).Distinct())
                {
                    var controllerPermission = group.AddPermission($"{p}.{controller}").WithProviders(RolePathPermissionValueProvider.ProviderName);
                    foreach (var action in policyControllerActions.Where(v => v.controller == controller).Select(v => v.action).Distinct())
                    {
                        controllerPermission.AddChild($"{p}.{controller}.{action}").WithProviders(RolePathPermissionValueProvider.ProviderName);
                    }
                }
            }
        }
    }
}
