﻿using System;

namespace ABP.LiteProject.Shared
{
    public class ABPLiteProjectSharedModule 
    {
    }
}
