﻿namespace ABP.LiteProject.Shared.Constants
{
    class Class1
    {
    }
}
